#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/robot_hw.h>
#include <joint_limits_interface/joint_limits.h>
#include <joint_limits_interface/joint_limits_interface.h>
#include <joint_limits_interface/joint_limits_rosparam.h>
//#include <joint_limits_interface/joint_limits_urdf.h>
#include <controller_manager/controller_manager.h>
#include <boost/scoped_ptr.hpp>
#include <ros/ros.h>
#include <rospy_tutorials/Floats.h>
#include <three_dof_planar_manipulator/Floats_array.h>
#include <angles/angles.h>

#define LOOP_RATE 10

class ROBOTHardwareInterface : public hardware_interface::RobotHW {
protected:
	ros::Publisher pub;
	ros::ServiceClient client;

	// Interfaces
    hardware_interface::JointStateInterface joint_state_interface_;									// Interface for checking state of joints
    hardware_interface::EffortJointInterface effort_joint_interface_;								// Interface for checking efforts applied to joints
    joint_limits_interface::EffortJointSaturationInterface effortJointSaturationInterface;			// Checking saturation

    double joint_position_[2],						// Array of positions
	 		joint_velocity_[2],						// Array of velocities
			joint_effort_[2],						// Array of applied efforts
			joint_effort_command_[2];				// Array of efforts to handle joints control

    ros::NodeHandle nh_;							// Main node
    ros::Timer non_realtime_loop_;					// Timer
    ros::Duration elapsed_time_;					// Data for creating PWM signal
    boost::shared_ptr<controller_manager::ControllerManager> controller_manager_;

public:
	ROBOTHardwareInterface(ros::NodeHandle& nh);
	~ROBOTHardwareInterface();
	void init();									// Initialize object
	void update(const ros::TimerEvent& e);			// Timer-controlled update for data
	void read();									// Read state of joints
	void write(ros::Duration elapsed_time);			// Apply efforts to joints
};
