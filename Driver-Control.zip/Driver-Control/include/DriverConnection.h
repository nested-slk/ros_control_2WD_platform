#ifndef DRIVER_CONNECTION
#define DRIVER_CONNECTION

#include "ros/ros.h"
#include <rospy_tutorials/Floats.h>

#define LOOP_RATE 2

class DriverConnection {
private:
	ros::NodeHandle node;									// Node handler for ROS
	double f_effort = 0,									// Effort to the first motor
			s_effort = 0,									// Effort to the second motor
			f_velocity = 0,									// Velocity of the first motor
			s_velocity = 0;									// Velocity of the second motor

	long encoderPosition = 0;								// Current state of the first encoder

	ros::Publisher publisher;								// Publishing data through ROS topic system
	ros::Subscriber subscriber;								// Getting data through ROS topic system
	//rospy_tutorials::Floats joint_state;					// Data package to transmit data

	void setEffort(const rospy_tutorials::Floats&);			// Callback for updating the effort value
	void calculate(void);									// Calculate nev values for the motor
	void publishData(void);									// Update data about the motor
	void move(void);										// Change state of the motor
	void readEncoderData(void);

public:
	DriverConnection();
	void start(void);										// Start ROS main loop
};

#endif /* end of include guard:  */
