#include "DriverConnection.h"

DriverConnection::DriverConnection() {
	ROS_INFO("[DriverConnection::DriverConnection()] Object created");

	// Time Zero guard
	while (ros::ok() && ros::Time(0) == ros::Time::now()) {
		ROS_INFO("[DriverConnection::DriverConnection] Time Zero. Waiting...");
		sleep(1);
	}

	// TODO : Make topics' names be changable through launchfile

	// Publish and subscribe to essential topics
	publisher = node.advertise<rospy_tutorials::Floats>("/joint_states_from_arduino", 1);
	subscriber = node.subscribe("/joints_to_aurdino", 1, &DriverConnection::setEffort, this);

	ROS_INFO("[DriverConnection::DriverConnection()] Object initialized");
}

void DriverConnection::setEffort( const rospy_tutorials::Floats& msg ){
	// Set new value of effort
	f_effort = msg.data[0];
	s_effort = msg.data[1];

	// Print new value
	ROS_INFO("[DriverConnection::setEffort] New effort values : [%f], [%f]", f_effort, s_effort);
}

void DriverConnection::calculate(void) {
	/*
	static double previousTime = 0,					// Last time velocity was measured
					previousPosition = 0;			// Previous state of the encoder

	double time = ros::Time::now().toSec(),			// Current time
			temp_velocity = (360.0 *100.0 * (encoderPosition - previousPosition))
						/(2200.0 * (time - previousTime));

	if ((encoderPosition < -2 || encoderPosition > 2)
		&& (temp_velocity >= -60)
		&& (temp_velocity <= 60) )		// Guard the encoder at the boundaries
			velocity = temp_velocity;

	// Update essential values
	previousTime = time;
	previousPosition = encoderPosition;
	*/
}

void DriverConnection::publishData(void) {
	rospy_tutorials::Floats joint_state;				// Data package to transmit data
	joint_state.data.push_back(f_velocity);				// Publish first velocity
	joint_state.data.push_back(s_velocity);				// Publish second velocity

	// Publish data
	publisher.publish(joint_state);
}

void DriverConnection::readEncoderData(void) {}

void DriverConnection::move(void) {}

void DriverConnection::start(void) {
	// Set loop rate
	ros::Rate loop_rate(LOOP_RATE);

	// Call to enable callbacks
	ros::spinOnce();

	while (ros::ok()) {
		// Read data from encoder
		//readEncoderData();

		// Calculate new values
		calculate();

		// Apply some efforts to the motor
		// move();

		// Publish new messages
		publishData();

		// Sleep for to match the predefined rate
		loop_rate.sleep();
	}
}
