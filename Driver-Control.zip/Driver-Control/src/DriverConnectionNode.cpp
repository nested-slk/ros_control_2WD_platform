#include "ros/ros.h"
#include "DriverConnection.h"

int main( int argc, char **argv ) {
	// Initialize ROS
	ros::init(argc, argv, "driver_control");

	ROS_INFO("Started");

	// Create and start handler
	DriverConnection handler;
	handler.start();

	// End the program
	return 0;
}
