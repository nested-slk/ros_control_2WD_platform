#!/usr/bin/env python
import rospy
from rospy_tutorials.msg import Floats
from three_dof_planar_manipulator.srv import Floats_array, Floats_arrayResponse, Floats_arrayRequest

first_velocity = 0
second_velocity = 0
first_position = 0
second_position = 0

def firstWheelCallback(msg):
	global first_velocity, first_position

	first_position = msg.data[1]
	first_velocity = msg.data[2]

	print "[subscriber_py::firstWheelCallback] First velocity : ", first_velocity, "First position : ", first_position


def secondWheelCallback(msg):
	global second_velocity, second_position

	second_position = msg.data[1]
	second_velocity = msg.data[2]

	print "[subscriber_py::secondWheelCallback] Second velocity : ", second_velocity, "Second position : ", second_position


def my_server(req):
    global first_velocity, second_velocity, first_position, second_position
    res = Floats_arrayResponse()
    res.res=[first_position, first_velocity, second_position, second_velocity]
    return res

# Initialzing the node with name "subscriber_py"
rospy.init_node('subscriber_py')
print "[Subscriber_py] Node created"

rospy.Subscriber("/first_wheel", Floats, firstWheelCallback, queue_size=10)
rospy.Subscriber("/second_wheel", Floats, secondWheelCallback, queue_size=10)
rospy.Service('/read_joint_state', Floats_array, my_server)

rospy.spin()
